<template>
      <div class="py-4 main">
            <div class="container">
                  <div class="row justify-content-center">
                        <slot></slot>
                  </div>
            </div>
      </div>
</template>

<script>
export default {
  name: "container"
};
</script>

<style>
</style>
