export default {
    currentUser: localStorage.getItem("currentUser") || null
};
