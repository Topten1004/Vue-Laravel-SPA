export { default as Home } from "./Home/Home.vue";
export { Login, Register } from "./Auth";
export { default as Dashboard } from "./Dashboard/Index";
export {default as CreateAuthor} from './Author/Create';
