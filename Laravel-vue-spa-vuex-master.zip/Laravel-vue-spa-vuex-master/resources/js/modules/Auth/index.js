export { default as Login } from "./Login/Index";
export { default as Register } from "./Register/Index";
