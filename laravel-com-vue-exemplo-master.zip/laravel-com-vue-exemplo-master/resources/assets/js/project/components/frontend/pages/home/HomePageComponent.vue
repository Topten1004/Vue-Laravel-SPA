<template>
  <div>
      <h1>Home page do site</h1>
  </div>
</template>
