<template>
  <div class="container">
      <h1>Página de 404</h1>
  </div>
</template>
