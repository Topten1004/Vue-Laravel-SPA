<template>
    <div class="container">
        <h1>Adicionar Novo Produto</h1>

        <form-product-component></form-product-component>
    </div>
</template>

<script>
import FormProductComponent from './partials/FormProductComponent'

export default {
    components: {
        FormProductComponent
    }
}
</script>

